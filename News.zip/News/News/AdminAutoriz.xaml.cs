﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace News
{
    /// <summary>
    /// Логика взаимодействия для AdminAutoriz.xaml
    /// </summary>
    public partial class AdminAutoriz : Window
    {
        NewsEntities db = new NewsEntities();
        Administrator administrator = new Administrator();
        public AdminAutoriz()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (db.Administrator.Where(r => r.Login == Login.Text && r.Password == Password.Text).Count() > 0)
                {
                    //Class.log = Login.Text;
                    AdminUsersArtic usersArtic = new AdminUsersArtic();
                    usersArtic.Show();
                    this.Close();
                }
                else
                {
                    Login.Text = "";
                    Password.Text = "";
                    MessageBox.Show("Ошибка!");
                }
            }
            catch
            {

            }
            
           
        }
    }
}
