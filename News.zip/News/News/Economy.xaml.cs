﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace News
{
    /// <summary>
    /// Логика взаимодействия для Economy.xaml
    /// </summary>
    public partial class Economy : Window
    {
        NewsEntities db = new NewsEntities();
        Articles articles = new Articles();

        int n = 0;
        public Economy()
        {
            InitializeComponent();

            foreach (var user in db.Articles)
            {
                if (n == 0)
                {
                    text.Text = user.ArticleName + "\n" + user.Content.ToString();
                    n = 1;
                }
                else if (n == 1)
                {
                    text1.Text = user.ArticleName + "\n" + user.Content.ToString();
                    n = 2;
                }
                else if (n == 2)
                {
                    text2.Text = user.ArticleName + "\n" + user.Content.ToString();
                    n = 3;
                }
                else if (n == 3)
                {
                    text3.Text = user.ArticleName + "\n" + user.Content.ToString();
                }

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Label_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

            
            text.Text = Convert.ToString(articles.Content);

        }
    }
}
