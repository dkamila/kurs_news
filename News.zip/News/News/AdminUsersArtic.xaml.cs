﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace News
{
    /// <summary>
    /// Логика взаимодействия для AdminUsersArtic.xaml
    /// </summary>
    public partial class AdminUsersArtic : Window
    {
        NewsEntities db = new NewsEntities();
        UsersArticle usersArticle = new UsersArticle();
        public AdminUsersArtic()
        {
            InitializeComponent();
            foreach(var user in db.UsersArticle)
            {
                if(user.Check == 0)
                {
                    text.Text=user.UsersArticleName + "\n" + user.Author + "\n" + user.Content;
                    usersArticle = user;
                    break;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            EditArtic editArtic = new EditArtic();
            editArtic.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            db.UsersArticle.Remove(usersArticle);
            db.SaveChanges();
            foreach (var user in db.UsersArticle)
            {
                if (user.Check == 0)
                {
                    text.Text = user.UsersArticleName + "\n" + user.Author + "\n" + user.Content;
                    usersArticle = user;
                    break;
                }
            }

        }
    }
}
