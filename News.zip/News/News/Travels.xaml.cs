﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace News
{
    /// <summary>
    /// Логика взаимодействия для Travels.xaml
    /// </summary>
    public partial class Travels : Window
    {
        NewsEntities db = new NewsEntities();
        Articles articles = new Articles();
        int n = 1;
        public Travels()
        {
            InitializeComponent();
            foreach (var user in db.Articles)

            {
                if (n == 1) { n = 2; }
                else if (n == 2) { n = 3; }
                else if (n == 3) { n = 4; }
                else if (n == 4) { n = 5; }
                else if (n == 5) { n = 6; }
                else if (n == 6) { n = 7; }
                else if (n == 7) { n = 8; }
                else if (n == 8) { n = 9; }
                else if (n == 9) { n = 10; }
                else if (n == 10) { n = 11;}
                else if (n == 11){n = 12;}
                else if (n == 12){ n = 13; }
                else if (n == 13)
                {
                    text.Text = user.ArticleName + "\n" + user.Content.ToString();
                    n = 14;
                }
                else if (n == 14)
                {
                    text1.Text = user.ArticleName + "\n" + user.Content.ToString();
                    n = 15;
                }
                else if (n == 15)
                {
                    text2.Text = user.ArticleName + "\n" + user.Content.ToString();
                    n = 16;
                }
                else if (n == 16)
                {
                    text3.Text = user.ArticleName + "\n" + user.Content.ToString();
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
