﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace News
{
    /// <summary>
    /// Логика взаимодействия для EditArtic.xaml
    /// </summary>
    public partial class EditArtic : Window
    {
        NewsEntities db = new NewsEntities();
        UsersArticle UsersArticle = new UsersArticle();
        public EditArtic()
        {
            InitializeComponent();
            foreach (var user in db.UsersArticle)
            {
                if (user.Check == 0)
                {
                    text.Text = user.UsersArticleName;
                    text1.Text = user.Author ;
                    text2.Text = user.Content;
                    UsersArticle = user;
                    break;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AdminUsersArtic adminUsersArtic = new AdminUsersArtic();
            adminUsersArtic.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            UsersArticle.UsersArticleName = text.Text;
            UsersArticle.Author = text1.Text;
            UsersArticle.Content = text2.Text;
            UsersArticle.Check = 1;
           
            db.SaveChanges();
            text.Text ="";
            text1.Text ="";
            text2.Text ="";


        }
    }
}
